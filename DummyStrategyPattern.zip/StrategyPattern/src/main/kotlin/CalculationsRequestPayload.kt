data class CalculationsRequestPayload(
    val age: Int,
    val monthlyExpense: Int,
    val monthlyIncome: Int,
    val expensesAmount: Int,
    val incomeStartAfter: Int,
    val annualIncome: Int
)