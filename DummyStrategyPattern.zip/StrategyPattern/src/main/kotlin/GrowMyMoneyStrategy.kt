

//2.Create concrete classes implementing the same interface
class GrowMyMoneyStrategy : CalculationStrategy {
    //overriding Strategy fun
    override fun calculate(calculationsRequestDTO: CalculationsRequestDTO): Any {
        val savings = (calculationsRequestDTO.requestPayload.monthlyIncome) -
                (calculationsRequestDTO.requestPayload.monthlyExpense)
        val investmentPercentage=30
        val per = investmentPercentage.toDouble() / 100
        val investmentAmount = per * savings
        return investmentAmount.toLong()
    }
}


