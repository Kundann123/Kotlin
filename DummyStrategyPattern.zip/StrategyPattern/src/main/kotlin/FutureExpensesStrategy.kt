import kotlin.math.pow

//2.Create concrete classes implementing the same interface
class FutureExpensesStrategy : CalculationStrategy {
    override fun calculate(calculationsRequestDTO: CalculationsRequestDTO): Any {
        val inflationRate = 0.06
        val years = calculationsRequestDTO.requestPayload.incomeStartAfter
        val amount = calculationsRequestDTO.requestPayload.expensesAmount
        return amount * ((1 + inflationRate).pow(years.toDouble()))
    }
}
