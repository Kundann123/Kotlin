data class CalculationsRequestDTO(
    val productType:String,
    val finGoalType:String,
    val calculationType: String,
    val requestPayload:CalculationsRequestPayload
)