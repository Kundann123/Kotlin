
//3.Create Context Class.
class CustomerProfileService(private val strategy: CalculationStrategy) {

    fun graphCalculations(calculationsRequestDTO: CalculationsRequestDTO): Any {
        return strategy.calculate(calculationsRequestDTO)
    }
}
