
//1.Strategy Interface

interface CalculationStrategy {
    fun calculate(calculationsRequestDTO: CalculationsRequestDTO): Any
}
