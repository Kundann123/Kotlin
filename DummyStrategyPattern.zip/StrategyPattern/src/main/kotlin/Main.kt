fun main() {
    val calculationsRequestDTO = CalculationsRequestDTO(
        "lifeterm",
        "GrowMyMoney",
        "AMOUNT",
        CalculationsRequestPayload(
            20,
            10000,
            20000,
            10000,
            10,
            100000
        )
    )

    //Here we are setting Strategy.
    val strategy = when {
        calculationsRequestDTO.finGoalType == "GrowMyMoney" && calculationsRequestDTO.calculationType.equals("AMOUNT",
            ignoreCase = true
        ) -> GrowMyMoneyStrategy()

        calculationsRequestDTO.finGoalType == "EarlyRetirement" && calculationsRequestDTO.calculationType.equals("AMOUNT",
            ignoreCase = true
        ) ->FutureExpensesStrategy()

        else -> throw IllegalArgumentException("Invalid calculation strategy")
    }

    //4.Use the Context to see change in behaviour when it changes its Strategy.
    val profileService = CustomerProfileService(strategy).graphCalculations(calculationsRequestDTO)
    println("profileService: $profileService")
}
