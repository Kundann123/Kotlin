
rootProject.name = "StrategyPattern"

