#! /bin/sh
set -a
. /mnt/application.properties
set +a
cd /app/bin
./guaranteedSavings
