package com.tdl.guaranteedsavings.dto


data class PolicyGenerateDTO(

    val platformParameters: PlatformParameters,
    val requestPayload: RequestPayloadDTO
)
