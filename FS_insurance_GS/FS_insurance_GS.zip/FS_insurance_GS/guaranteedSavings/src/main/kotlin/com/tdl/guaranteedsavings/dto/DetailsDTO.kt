package com.tdl.guaranteedsavings.dto

import com.google.gson.annotations.SerializedName

data class DetailsDTO(

    @SerializedName("SearchInCkycResponseDetails")
    val searchInCkycResponseDetails:SearchInCkycResponseDetails
)
