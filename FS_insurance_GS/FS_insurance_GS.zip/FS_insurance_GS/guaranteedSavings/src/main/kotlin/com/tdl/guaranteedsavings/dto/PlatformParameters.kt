package com.tdl.guaranteedsavings.dto

data class PlatformParameters(
    val provider: String
)
