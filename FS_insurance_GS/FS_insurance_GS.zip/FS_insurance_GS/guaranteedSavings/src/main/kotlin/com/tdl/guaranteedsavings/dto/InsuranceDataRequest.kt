package com.tdl.guaranteedsavings.dto

data class InsuranceDataRequest (
    var planId:String?,
    var customerHash:String?

)
