package com.tdl.guaranteedsavings.dto

data class ValidateDocumentDTO(

    val platformParameters: PlatformParameters,
    val requestPayload: RequestPayload
)
