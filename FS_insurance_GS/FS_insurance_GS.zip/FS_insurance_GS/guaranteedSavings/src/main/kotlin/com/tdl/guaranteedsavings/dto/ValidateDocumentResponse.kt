package com.tdl.guaranteedsavings.dto


data class ValidateDocumentResponse(
    val httpStatusCode: String,
    val message: String
)
