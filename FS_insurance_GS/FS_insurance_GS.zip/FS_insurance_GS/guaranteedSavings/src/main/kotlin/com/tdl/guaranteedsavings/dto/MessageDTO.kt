package com.tdl.guaranteedsavings.dto

data class MessageDTO(val message: String)
