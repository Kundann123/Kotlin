package com.tdl.guaranteedsavings.dto

import com.google.gson.annotations.SerializedName

data class CkycIdDetails(

    @SerializedName("ID")
    val id: List<ID>
)
