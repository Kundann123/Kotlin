package com.tdl.guaranteedsavings.exception

class GSInternalServerException(
    override val message: String?
) : Exception(message)
