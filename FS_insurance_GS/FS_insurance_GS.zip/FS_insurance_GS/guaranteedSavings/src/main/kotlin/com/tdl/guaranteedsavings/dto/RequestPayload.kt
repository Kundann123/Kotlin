package com.tdl.guaranteedsavings.dto

data class RequestPayload(
    val docs: Docs
)
