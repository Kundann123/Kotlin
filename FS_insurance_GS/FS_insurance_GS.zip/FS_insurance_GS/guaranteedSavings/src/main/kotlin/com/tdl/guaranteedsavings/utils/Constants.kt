package com.tdl.guaranteedsavings.utils

object Constants {
    const val CONTENT_TYPE = "Content-Type"
    const val JSON_CONTENT = "application/json"
}
